import pygame

class TouchButton:
    def __init__(self, x, y, width = 100, height = 40, text="Button", color = (255, 255, 255), hover_color=(200, 200, 200), is_holdable = False):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.current_color = color
        self.pressed = False
        self.is_holdable = is_holdable
        self.font = pygame.font.SysFont(None, 30)

    def draw(self, screen):
        pygame.draw.rect(screen, self.current_color, self.rect, 2)
        text_surf = self.font.render(self.text, True, (255, 255, 255))
        text_rect = text_surf.get_rect(center=self.rect.center)
        screen.blit(text_surf, text_rect)

    def handle_event(self, event, screen_width, screen_height):
        # 1. 꾹 누르기용 버튼 처리 (이동 가상 패드용)
        if self.is_holdable:
            # 실시간으로 화면을 누르고 있는 모든 활성화된 손가락들의 정보를 가져옵니다.
            num_fingers = pygame._sdl2.touch.get_num_fingers(0) if hasattr(pygame, '_sdl2') else 0
            
            # 모바일 멀티터치 실시간 갱신 검사
            if num_fingers > 0:
                for i in range(num_fingers):
                    finger = pygame._sdl2.touch.get_finger(0, i)
                    if finger:
                        px = int(finger['x'] * screen_width)
                        py = int(finger['y'] * screen_height)
                        if self.rect.collidepoint(px, py):
                            self.pressed = True
                            self.current_color = self.hover_color
                            return False # 멀티터치 흐름이 끊기지 않도록 False 반환
            
            # 모바일 터치가 없다면 PC 마우스 실시간 누름 검사 (하이브리드 호환)
            else:
                mouse_pressed = pygame.mouse.get_pressed()
                mouse_pos = pygame.mouse.get_pos()
                if mouse_pressed[0] and self.rect.collidepoint(mouse_pos):
                    self.pressed = True
                    self.current_color = self.hover_color
                    return False
            
            # 아무것도 누르고 있지 않다면 상태 초기화
            if event.type in (pygame.FINGERUP, pygame.MOUSEBUTTONUP, pygame.KEYUP):
                self.pressed = False
                self.current_color = self.color

        # 2. 한 번만 누르기용 버튼 처리 (y=..., Reset UI 버튼용)
        else:
            if event.type == pygame.FINGERDOWN:
                px = int(event.x * screen_width)
                py = int(event.y * screen_height)
                if self.rect.collidepoint(px, py):
                    self.pressed = False # 일시정지 전 즉시 리셋하여 무한 연타 차단
                    self.current_color = self.color
                    return True

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and self.rect.collidepoint(event.pos):
                    self.pressed = False
                    self.current_color = self.color
                    return True

        return False

class ImageTouchButton(TouchButton):
    def __init__(self, x, y, image_surface, is_holdable = False):
        super().__init__(x, y, is_holdable=is_holdable)
        self.x = x
        self.y = y
        self.image_surface = image_surface
        self.rect = self.image_surface.get_rect(topleft=(x, y))

    def draw(self, screen):
        screen.blit(self.image_surface, (self.x, self.y))
# import pygame
# class TouchButton:
#     def __init__(self, x, y, width = 100, height = 40, text="Button", color = (255, 255, 255), hover_color=(200, 200, 200)):
#         self.rect = pygame.Rect(x, y, width, height)
#         self.text = text
#         self.color = color
#         self.hover_color = hover_color
#         self.current_color = color
#         self.pressed = False
        
#         self.font = pygame.font.SysFont(None, 30)
        
#         self.pressed_finger_id = None
#         self.mouse_pressed = False

#     def draw(self, screen):
#         pygame.draw.rect(screen, self.current_color, self.rect,2)
        
#         text_surf = self.font.render(self.text, True, (255, 255, 255))
#         text_rect = text_surf.get_rect(center=self.rect.center)
#         screen.blit(text_surf, text_rect)

#     # def handle_event(self, event, screen_width, screen_height):
#     #     if event.type == pygame.FINGERDOWN:
#     #         px = int(event.x * screen_width)
#     #         py = int(event.y * screen_height)
#     #         if self.rect.collidepoint(px, py) and self.pressed_finger_id is None:
#     #             self.pressed_finger_id = event.fingerId
#     #             self.current_color = self.hover_color
#     #             self.pressed = True
#     #             return True

#     #     elif event.type == pygame.FINGERUP:
#     #         if event.fingerId == self.pressed_finger_id:
#     #             self.pressed_finger_id = None
#     #             self.current_color = self.color
#     #             self.pressed = False

#     #     # PC testing with mouse events
#     #     elif event.type == pygame.MOUSEBUTTONDOWN:
#     #         if event.button == 1:
#     #             if self.rect.collidepoint(event.pos):
#     #                 self.mouse_pressed = True
#     #                 self.pressed = True
#     #                 self.current_color = self.hover_color
#     #                 return True

#     #     elif event.type == pygame.MOUSEBUTTONUP:
#     #         if event.button == 1 and self.mouse_pressed:
#     #             self.mouse_pressed = False
#     #             self.pressed = False
#     #             self.current_color = self.color

#     #     return False
#     def handle_event(self, event, screen_width, screen_height):
#         if event.type == pygame.FINGERDOWN:
#             px = int(event.x * screen_width)
#             py = int(event.y * screen_height)
#             if self.rect.collidepoint(px, py):
#                 self.current_color = self.color
#                 self.pressed = False 
#                 return True

#         elif event.type == pygame.MOUSEBUTTONDOWN:
#             if event.button == 1:
#                 if self.rect.collidepoint(event.pos):
#                     self.current_color = self.color
#                     self.pressed = False
#                     return True

#         elif event.type in (pygame.FINGERUP, pygame.MOUSEBUTTONUP):
#             self.current_color = self.color
#             self.pressed = False

#         elif event.type == pygame.FINGERMOTION:
#             px = int(event.x * screen_width)
#             py = int(event.y * screen_height)
#             if self.rect.collidepoint(px, py):
#                 self.pressed = True
#             else:
#                 self.pressed = False

#         return False
# class ImageTouchButton(TouchButton):
#     def __init__(self, x, y, image_surface):
        
#         super().__init__(x, y)
#         self.x = x
#         self.y = y
#         self.image_surface = image_surface
#         self.rect = self.image_surface.get_rect(topleft=(x, y))

#     def draw(self, screen):
#         screen.blit(self.image_surface, (self.x, self.y))