import pygame
class TouchButton:
    def __init__(self, x, y, width = 100, height = 40, text="Button", color = (255, 255, 255), hover_color=(200, 200, 200)):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.current_color = color
        self.pressed = False
        
        self.font = pygame.font.SysFont(None, 30)
        
        self.pressed_finger_id = None
        self.mouse_pressed = False

    def draw(self, screen):
        pygame.draw.rect(screen, self.current_color, self.rect,2)
        
        text_surf = self.font.render(self.text, True, (255, 255, 255))
        text_rect = text_surf.get_rect(center=self.rect.center)
        screen.blit(text_surf, text_rect)

    # def handle_event(self, event, screen_width, screen_height):
    #     if event.type == pygame.FINGERDOWN:
    #         px = int(event.x * screen_width)
    #         py = int(event.y * screen_height)
    #         if self.rect.collidepoint(px, py) and self.pressed_finger_id is None:
    #             self.pressed_finger_id = event.fingerId
    #             self.current_color = self.hover_color
    #             self.pressed = True
    #             return True

    #     elif event.type == pygame.FINGERUP:
    #         if event.fingerId == self.pressed_finger_id:
    #             self.pressed_finger_id = None
    #             self.current_color = self.color
    #             self.pressed = False

    #     # PC testing with mouse events
    #     elif event.type == pygame.MOUSEBUTTONDOWN:
    #         if event.button == 1:
    #             if self.rect.collidepoint(event.pos):
    #                 self.mouse_pressed = True
    #                 self.pressed = True
    #                 self.current_color = self.hover_color
    #                 return True

    #     elif event.type == pygame.MOUSEBUTTONUP:
    #         if event.button == 1 and self.mouse_pressed:
    #             self.mouse_pressed = False
    #             self.pressed = False
    #             self.current_color = self.color

    #     return False
    def handle_event(self, event, screen_width, screen_height):
        # 1. 모바일 터치 시작 (FINGERDOWN)
        if event.type == pygame.FINGERDOWN:
            px = int(event.x * screen_width)
            py = int(event.y * screen_height)
            if self.rect.collidepoint(px, py):
                self.pressed_finger_id = event.fingerId
                self.current_color = self.hover_color
                self.pressed = True
                return True

        # 2. 모바일 터치 뗌 (FINGERUP)
        elif event.type == pygame.FINGERUP:
            if event.fingerId == self.pressed_finger_id:
                self.pressed_finger_id = None
                self.current_color = self.color
                self.pressed = False

        # 3. PC 마우스 클릭 시작 (MOUSEBUTTONDOWN)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if self.rect.collidepoint(event.pos):
                    self.current_color = self.hover_color
                    self.pressed = True
                    return True

        # 4. PC 마우스 클릭 뗌 (MOUSEBUTTONUP)
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:
                self.current_color = self.color
                self.pressed = False

        return False
class ImageTouchButton(TouchButton):
    def __init__(self, x, y, image_surface):
        
        super().__init__(x, y)
        self.x = x
        self.y = y
        self.image_surface = image_surface
        self.rect = self.image_surface.get_rect(topleft=(x, y))

    def draw(self, screen):
        screen.blit(self.image_surface, (self.x, self.y))