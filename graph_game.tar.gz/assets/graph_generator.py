#-*- coding: utf-8 -*-
import pygame #pygame-ce
import math
import re

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

POSITION_SCALE = 20  # Scale factor for converting graph coordinates to pixel coordinates
GRAPH_RANGE = 20
GRAPH_DENSITY = SCREEN_WIDTH // (GRAPH_RANGE * 2)  # Number of points per unit length on the x-axis
MAX_JUMP_PIXEL = SCREEN_HEIGHT * 0.8  # Maximum allowed jump in y-values between consecutive points

LINE_THICKNESS = 4

def set_graph_dots(exprStr):
    exprStr = exprStr.replace('^', '**')
    
    exprStr = re.sub(r'(\d)([a-zA-Z]+)', r'\1*\2', exprStr)
    exprStr = re.sub(r'(?<!sin)(?<!cos)(?<!tan)(?<!abs)(?<!sqrt)(?<!pi)(\b\d+|\b[a-zA-Z]|\))(\()', r'\1*\2', exprStr)
    exprStr = re.sub(r'(\))([a-zA-Z\d])', r'\1*\2', exprStr)
    
    allowed_words = {
        'x': 0, 
        'sin': math.sin, 'cos': math.cos, 'tan': math.tan,
        'pi': math.pi, 'e': math.e, 'sqrt': math.sqrt, 'abs': abs
    }
    
    dots = []
    graph_range = GRAPH_RANGE * GRAPH_DENSITY
    graph_step = 1 / GRAPH_DENSITY
    range_values = [i * graph_step for i in range(-graph_range, graph_range + 1)]
    
    for x_val in range_values:
        allowed_words['x'] = x_val
        try:
            y_val = eval(exprStr, {"__builtins__": None}, allowed_words)
            dots.append((x_val, y_val))
        except:
            continue
    return dots

def set_graph_lines(dots):
    lines = []
    i = 0
    while i < len(dots) - 1:
        start_x = dots[i][0]
        start_y = dots[i][1]
        end_x = dots[i + 1][0]
        end_y = dots[i + 1][1]
        if undifined_or_not_real(start_y):
            i += 1
            continue
        if undifined_or_not_real(end_y):
            i += 2  # Skip the next point as well since the current segment is invalid
            continue
        start_pixel = position_to_pixel(start_x, start_y)
        end_pixel = position_to_pixel(end_x, end_y)
        if abs(end_pixel[1] - start_pixel[1]) > MAX_JUMP_PIXEL:
            i += 1
            continue
        lines.append((start_pixel, end_pixel))
        i += 1
    return lines

def generate_lines(expr_str):
    return set_graph_lines(set_graph_dots(expr_str))

def undifined_or_not_real(y,max_y=5000):
    try:
        if isinstance(y, complex):
            return True
        if abs(y) > max_y:
            return True
        return False
    except:
        return True

def draw_lines(screen, line_list):
    for start_pixel, end_pixel in line_list:
        pygame.draw.line(screen, (255, 0, 0), start_pixel, end_pixel, LINE_THICKNESS)

def check_collide_lines(box, line_list):
    for line in line_list:
        start_pixel, end_pixel = line
        if box.clipline(start_pixel, end_pixel):
            return line
    return None
    



# def main():
#     pygame.init()
#     screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
#     pygame.display.set_caption("Graph Generator")
#     clock = pygame.time.Clock()
    
#     lines = generate_lines(exprStr)

#     box_x_pos = -20
#     running = True
#     while running:
#         for event in pygame.event.get():
#             if event.type == pygame.QUIT:
#                 running = False

#         screen.fill((255, 255, 255))

#         # Draw axes
#         pygame.draw.line(screen, (0, 0, 0), (SCREEN_WIDTH // 2, 0), (SCREEN_WIDTH // 2, SCREEN_HEIGHT), 2)
#         pygame.draw.line(screen, (0, 0, 0), (0, SCREEN_HEIGHT // 2), (SCREEN_WIDTH, SCREEN_HEIGHT // 2), 2)

#         draw_lines(screen,lines)

#         box_x_pos += 0.2
#         box_rect = pygame.Rect(*position_to_pixel(box_x_pos, 0), 50, 50)
#         box = pygame.draw.rect(screen, (0, 0, 255), box_rect)
#         for line in lines:
#             start_pixel, end_pixel = line
#             if box.clipline(start_pixel, end_pixel):
#                 print(f"Box at x={box_x_pos} is on the graph.")
#                 pygame.draw.rect(screen, (0, 255, 0), box_rect)  # Change color to green if on the graph
#                 break

#         pygame.display.flip()
#         clock.tick(60)

#     pygame.quit()



def position_to_pixel(x, y):
    pixel_x = x * POSITION_SCALE + SCREEN_WIDTH // 2
    pixel_y = -y * POSITION_SCALE + SCREEN_HEIGHT // 2
    try:
        return int(pixel_x), int(pixel_y)
    except:
        print(f"Error converting position to pixel: x={x}, y={y}, pixel_x={pixel_x}, pixel_y={pixel_y}")
        return 0, 0

# if(__name__ == "__main__"):
#     exprStr = input("Enter a mathematical expression: y=")
#     main()