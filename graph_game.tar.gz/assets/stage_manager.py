#-*- coding: utf-8 -*-
import pygame
import graph_generator

STAR_SIZE = 20
SPIKE_SIZE = 16

star_image = spike_image = None

def load_image():
    global star_image,spike_image
    star_image = pygame.image.load("images/Star.png")
    spike_image = pygame.image.load("images/Spike.png")

def generate_stage(stage_string):
    obstacles = []
    stars = []

    lines = stage_string.split(';')
    for line in lines:
        parts = line.split(',')
        if len(parts) < 3:
            continue
        obj_type = parts[0].strip()
        x = float(parts[1].strip())
        y = float(parts[2].strip())
        if obj_type == 'obstacle':
            width = float(parts[3].strip()) if len(parts) > 3 else 1
            height = float(parts[4].strip()) if len(parts) > 4 else 1
            if width <= 0 or height <= 0:
                print(f"Invalid obstacle dimensions: width={width}, height={height}. Skipping this obstacle.")
                continue  # Skip invalid obstacles
            obstacles.append(generate_obstacle(x, y, width, height))
        elif obj_type == 'star':
            stars.append(generate_star(x, y))

    return obstacles, stars

def generate_obstacle(x, y, width, height):
    (x, y) = graph_generator.position_to_pixel(x, y)
    (width, height) = width * graph_generator.POSITION_SCALE, height * graph_generator.POSITION_SCALE
    return pygame.Rect(x, y, width, height)

def generate_star(x, y):
    (x, y) = graph_generator.position_to_pixel(x, y)
    size = STAR_SIZE
    return pygame.Rect(x-size//2, y-size//2, size, size)  # Center the star around the position

def draw_stars(screen, stars, collected_stars):
    for i, star in enumerate(stars):
        if i not in collected_stars:
            if star_image:
                scaled_image = pygame.transform.scale(star_image, (STAR_SIZE, STAR_SIZE))
                screen.blit(scaled_image, (star.x, star.y))
            else:
                pygame.draw.rect(screen, (128, 255, 0), star)
def draw_obstacles(screen, obstacles):
    for obstacle in obstacles:
        inner, outer = (78, 90, 102), (100, 120, 140)
        pygame.draw.rect(screen, inner, obstacle)
        pygame.draw.rect(screen, outer, obstacle, 2) # 테두리
        if spike_image:
            draw_spike_box(screen, obstacle, spike_image, spike_size=(SPIKE_SIZE, SPIKE_SIZE), gap=0)

def draw_spike_box(surface, rect, spike_img, spike_size=(16, 16), gap=0):

    w, h = spike_size

    spike = pygame.transform.scale(spike_img, (w, h))
    spikes = {
        "top": spike,
        "bottom": pygame.transform.flip(spike, False, True),
        "left": pygame.transform.rotate(spike, 90),
        "right": pygame.transform.rotate(spike, -90)
    }

    def draw_edge(length, direction):
        count = max(1, int((length + gap) // (w + gap)))

        spacing = length / count

        for i in range(count):
            center = (i + 0.5) * spacing

            if direction == "top":
                pos = (rect.left + center - w/2, rect.top - h)

            elif direction == "bottom":
                pos = (rect.left + center - w/2, rect.bottom)

            elif direction == "left":
                pos = (rect.left - h, rect.top + center - w/2)

            elif direction == "right":
                pos = (rect.right, rect.top + center - w/2)

            surface.blit(spikes[direction], pos)

    draw_edge(rect.width, "top")
    draw_edge(rect.width, "bottom")
    draw_edge(rect.height, "left")
    draw_edge(rect.height, "right")

def main():
    pygame.init()
    screen = pygame.display.set_mode((graph_generator.SCREEN_WIDTH, graph_generator.SCREEN_HEIGHT))
    pygame.display.set_caption("stage manager")

    clock = pygame.time.Clock()
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        screen.fill((128, 128, 128))
        #축
        axis_color = (50,50,50)
        pygame.draw.line(screen,axis_color,(0,graph_generator.SCREEN_HEIGHT//2),(graph_generator.SCREEN_WIDTH,graph_generator.SCREEN_HEIGHT//2))
        pygame.draw.line(screen,axis_color,(graph_generator.SCREEN_WIDTH//2,0),(graph_generator.SCREEN_WIDTH//2,graph_generator.SCREEN_HEIGHT))

        obstacles, stars = generate_stage("obstacle,0,0,1,1;star,2,2;obstacle,-3,-1,2,0.5;star,-1,1")
        draw_obstacles(screen, obstacles)
        draw_stars(screen, stars, [])

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()

# if __name__ == "__main__":
#     main()