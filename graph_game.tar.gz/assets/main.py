#-*- coding: utf-8 -*-
import pygame
import player_controller
import graph_generator
import stage_manager
import button_controller
import asyncio
import sys

SCREEN_WIDTH, SCREEN_HEIGHT = 1000, 500
graph_generator.SCREEN_WIDTH = SCREEN_WIDTH
graph_generator.SCREEN_HEIGHT = SCREEN_HEIGHT
graph_generator.GRAPH_RANGE = int((1/25) * max(SCREEN_WIDTH, SCREEN_HEIGHT))  # Adjust GRAPH_RANGE based on the larger dimension
graph_generator.LINE_THICKNESS = 3

use_image = True  # Set to True if you want to use images for stars and functions
if not use_image:
    player_controller.SHOW_PLAYER_HITBOX = True

game_paused = False

stage = 1
stages = ["star,0,0;star,8,4;star,14,7;star,20,10;obstacle,10,0,6,2;star,10,-7;star,13,-7;star,16,-7",
          "obstacle,-15,-3,30,3;obstacle,-2.5,-0.5,5,3;obstacle,-2,10,4,6;star,-9,10;star,9,10;star,-5,-1;star,5,-1",
          "obstacle,-2,6,4,8;obstacle,-7,-2,9,2;obstacle,-9,12,2,10;obstacle,-9,12,14,2;obstacle,6,12,4,10;obstacle,6,-2,4,2;\
          star,8,0;star,4,-4"]
max_stage = len(stages)
stage_platform_nums = [2,1,2]
stage_player_pos = [graph_generator.position_to_pixel(-12,-5),graph_generator.position_to_pixel(-10,2),graph_generator.position_to_pixel(-5,0)]

def draw_axis(screen):
    axis_color = (50, 50, 50)
    font = pygame.font.Font(None, 20)
    pygame.draw.line(screen, axis_color, (0, SCREEN_HEIGHT // 2), (SCREEN_WIDTH, SCREEN_HEIGHT // 2))
    pygame.draw.line(screen, axis_color, (SCREEN_WIDTH // 2, 0), (SCREEN_WIDTH // 2, SCREEN_HEIGHT))
    for i in range(-graph_generator.GRAPH_RANGE, graph_generator.GRAPH_RANGE + 1,2):
        if i == 0:
            continue
        text_surface = font.render(str(i), True, axis_color)
        x = i * graph_generator.POSITION_SCALE + SCREEN_WIDTH // 2
        pygame.draw.line(screen, axis_color, (x, SCREEN_HEIGHT // 2 - 5), (x, SCREEN_HEIGHT // 2 + 5))
        screen.blit(text_surface, (x - text_surface.get_width() // 2, SCREEN_HEIGHT // 2 + 10))
        y = -i * graph_generator.POSITION_SCALE + SCREEN_HEIGHT // 2
        pygame.draw.line(screen, axis_color, (SCREEN_WIDTH // 2 - 5, y), (SCREEN_WIDTH // 2 + 5, y))
        screen.blit(text_surface, (SCREEN_WIDTH // 2 + 10, y - text_surface.get_height() // 2))

async def open_mobile_input(prompt_message="Enter the graph equation: y=", default_value=""):

    if sys.platform == "emscripten":
        from platform import window
        result = window.prompt(prompt_message, default_value)
        
        if result is not None:
            return str(result) 
        return default_value   
        
    else:
        print(f"\n[PC] {prompt_message}")
        result = input(f"y=")
        if result.strip():
            return result
        return default_value

async def main():
    global SCREEN_WIDTH, SCREEN_HEIGHT,stage
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Player Controller")

    font = pygame.font.Font(None, 40)

    clock = pygame.time.Clock()
    running = True

    first_platform = []
    stage_manager.STAR_SIZE = 30
    stage_manager.SPIKE_SIZE = 8
    obstacles, stars = stage_manager.generate_stage(stages[stage-1])
    first_player_pos = stage_player_pos[stage-1]
    player = player_controller.Player(*first_player_pos,first_platform,obstacles,stars, scale = 40,image_scale = 50, jump_force = 7)

    available_platforms_num = stage_platform_nums[stage-1]
    remaining_platforms_num = available_platforms_num
    
    stage_ui_pos = (SCREEN_WIDTH - 150,10)
    
    star_image = function_image = None
    if use_image:
        function_image = pygame.image.load("images/Function.png")
        player_controller.load_image()
        player.load_buttons()
        stage_manager.load_image()
        star_image = pygame.transform.scale(stage_manager.star_image, (40, 40))
        function_image = pygame.transform.scale(function_image, (40, 40))

        p = pygame.transform.scale(player_controller.movebutton_image,(60,60))
        n = pygame.transform.rotate(p,180)
        previous_button = button_controller.ImageTouchButton(stage_ui_pos[0]-30,stage_ui_pos[1]+50,p)
        next_button = button_controller.ImageTouchButton(stage_ui_pos[0]+30,stage_ui_pos[1]+50,n)
    reset_button = button_controller.TouchButton(10, 130, 100, 40, "Reset")
    input_button = button_controller.TouchButton(SCREEN_WIDTH // 2 - 150, SCREEN_HEIGHT-110, 300, 100, "y= ...")
    
    is_stage_clear = False
    
    while running:
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                
                player.update_button_events(event)
                
                def reset():
                    nonlocal player, remaining_platforms_num, is_stage_clear
                    player.platforms = []
                    player.respawn()
                    remaining_platforms_num = available_platforms_num
                    is_stage_clear = False

                def restart_stage():
                    nonlocal player, remaining_platforms_num, available_platforms_num
                    obstacles, stars = stage_manager.generate_stage(stages[stage-1])
                    available_platforms_num = stage_platform_nums[stage-1]
                    player.obstacles = obstacles
                    player.stars = stars
                    player.respawn_pos = stage_player_pos[stage-1]
                    reset()

                
                if reset_button.handle_event(event, SCREEN_WIDTH, SCREEN_HEIGHT):
                    reset()
                    
                if previous_button.handle_event(event, SCREEN_WIDTH, SCREEN_HEIGHT):
                    stage = max(1, stage - 1)
                    restart_stage()
                    
                if next_button.handle_event(event, SCREEN_WIDTH, SCREEN_HEIGHT):
                    stage = min(max_stage, stage + 1)
                    restart_stage()
                    
                if input_button.handle_event(event, SCREEN_WIDTH, SCREEN_HEIGHT):
                    if not game_paused and remaining_platforms_num > 0:
                        txt = await open_mobile_input()
                        
                        if txt:
                            platforms = graph_generator.generate_lines(txt)
                            if not platforms:
                                print("Invalid function input.")
                            else:
                                remaining_platforms_num -= 1
                                player.platforms.extend(platforms)
                                player.respawn()
        # for event in pygame.event.get():
        #     if event.type == pygame.QUIT:
        #         running = False
            
        #     player.update_button_events(event)
        #     def reset():
        #         nonlocal player,remaining_platforms_num, is_stage_clear
        #         player.platforms = []
        #         player.respawn()
        #         remaining_platforms_num = available_platforms_num
        #         is_stage_clear = False
        #     def restart_stage():
        #         nonlocal player,remaining_platforms_num,available_platforms_num
        #         obstacles, stars = stage_manager.generate_stage(stages[stage-1])
        #         available_platforms_num = stage_platform_nums[stage-1]
        #         player.obstacles = obstacles
        #         player.stars = stars
        #         player.respawn_pos = stage_player_pos[stage-1]
        #         reset()
        #     if reset_button.handle_event(event,SCREEN_WIDTH,SCREEN_HEIGHT):
        #         player.platforms = []
        #         player.respawn()
        #         remaining_platforms_num = available_platforms_num
        #     if previous_button.handle_event(event,SCREEN_WIDTH,SCREEN_HEIGHT):
        #         stage = max(1,stage-1)
        #         restart_stage()
        #     if next_button.handle_event(event,SCREEN_WIDTH,SCREEN_HEIGHT):
        #         stage = min(max_stage,stage+1)
        #         restart_stage()
        #     if input_button.handle_event(event,SCREEN_WIDTH,SCREEN_HEIGHT):
        #         if input_button.rect.collidepoint(event.pos) and not game_paused and remaining_platforms_num > 0:
        #             txt = await open_mobile_input()
        #             platforms = graph_generator.generate_lines(txt)
        #             if not platforms:
        #                 print("Invalid function input.")
        #                 continue
        #             remaining_platforms_num -= 1
        #             player.platforms.extend(platforms)
        #             player.respawn()
            # if event.type == pygame.KEYDOWN:
            #     if event.key == pygame.K_BACKSPACE:
            #         text = text[:-1]
            #     elif event.key == pygame.K_RETURN:
            #         if remaining_platforms_num <= 0:
            #             print("No remaining platforms available.")
            #             continue
            #         platforms = graph_generator.generate_lines(text)
            #         if not platforms:
            #             print("Invalid function input.")
            #             continue
            #         remaining_platforms_num -= 1
            #         player.platforms.extend(platforms)
            #         text = ""
            #     elif event.key == pygame.K_ESCAPE:
            #         player.platforms = []
            #     else:
            #         text += event.unicode
        player.controll()
        screen.fill((101,105,108))
        if game_paused:
            pause_text = font.render("Inputting text...", True, (255, 255, 0))
            screen.blit(pause_text, (300, 150))
        else:
            draw_axis(screen)

            graph_generator.draw_lines(screen,player.platforms)
            stage_manager.draw_obstacles(screen,player.obstacles)
            stage_manager.draw_stars(screen,player.stars, player.collection_star_indexs)
            player.draw_self(screen)

            #function text box
            # pygame.draw.rect(screen, (255, 255, 255), (0, SCREEN_HEIGHT-50, 400, 50), 2)
            # text_surface = font.render("y=" + text, True, (255, 255, 255))
            # screen.blit(text_surface, (10, SCREEN_HEIGHT-40))

            #star collection status
            if use_image:
                screen.blit(star_image, (10, 10))
            text_surface = font.render(f"{len(player.collection_star_indexs)} / {len(player.stars)}", True, (255, 255, 255))
            screen.blit(text_surface, (70,10))

            #stage clear text
            if len(player.collection_star_indexs) >= len(player.stars) and player.grounded:
                is_stage_clear = True
            
            if is_stage_clear:
                text_surface = font.render("STAGE CLEAR", True, (255, 215, 0))
                screen.blit(text_surface, (200,10))

            #number of remaining platforms
            if use_image:
                screen.blit(function_image, (10, 70))
            text_surface = font.render(f"{remaining_platforms_num} / {available_platforms_num}", True, (255, 255, 255))
            screen.blit(text_surface, (70, 70))
            
            #reset button
            reset_button.draw(screen)

            #input button
            input_button.draw(screen)
            #stage
            previous_button.draw(screen)
            next_button.draw(screen)
            text_surface = font.render(f"stage:{stage}", True, (255, 255, 255))
            screen.blit(text_surface, stage_ui_pos)

            for btn in player.buttons:
                btn.draw(screen)

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()
if __name__ == "__main__":
    asyncio.run(main())