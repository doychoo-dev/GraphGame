#-*- coding: utf-8 -*-
import pygame
import graph_generator
import button_controller

SHOW_PLAYER_HITBOX = False

player_image = None
movebutton_image = None
def load_image():
    global player_image,movebutton_image
    player_image = pygame.image.load("images/Player.png")
    movebutton_image = pygame.image.load("images/MoveButton.png")

class Player:
    def __init__(self, x, y, platforms = [],obstacles = [],stars = [], scale = 20, image_scale = -1, speed = 4, gravity = 0.2, jump_force = 5):
        self.x = x
        self.y = y
        self.platforms = platforms
        self.obstacles = obstacles
        self.stars = stars
        self.scale = scale
        self.image_scale = scale if image_scale == -1 else image_scale
        self.speed = speed
        self.gravity = gravity
        self.jump_force = jump_force
        self.velocity_y = 0
        self.max_velocity_y = 4
        self.grounded = False
        self.respawn_pos = (x, y)
        self.slope = None
        self.collection_star_indexs = []
        self.is_dead = False
        self.respawn_timer = 0
        self.is_frozen_after_respawn = True  # Freeze player movement after respawn until they move left or right
        self.respawn()  # Initialize the player state
        self.buttons = []
        self.button_events = set()
    
    def load_buttons(self):
        size = 120
        left_img = pygame.transform.scale(movebutton_image, (size, size))
        right_img = pygame.transform.rotate(left_img,180)
        up_img = pygame.transform.rotate(left_img,270)
        down_img = pygame.transform.rotate(left_img,90)
        reft_button = button_controller.ImageTouchButton(20,graph_generator.SCREEN_HEIGHT-size-10,left_img,is_holdable=True)
        right_button = button_controller.ImageTouchButton(size + 50,graph_generator.SCREEN_HEIGHT-size-10,right_img,is_holdable=True)
        up_button = button_controller.ImageTouchButton(graph_generator.SCREEN_WIDTH -size -50,graph_generator.SCREEN_HEIGHT-(2*size)-30,up_img,is_holdable=True)
        down_button = button_controller.ImageTouchButton(graph_generator.SCREEN_WIDTH -size -50,graph_generator.SCREEN_HEIGHT-(size)-10,down_img,is_holdable=True)
        self.buttons = [reft_button,right_button,up_button,down_button]

    def update_button_events(self,event):
        for btn in self.buttons:
            btn.handle_event(event,graph_generator.SCREEN_WIDTH,graph_generator.SCREEN_HEIGHT)

    def get_rect(self):
        half = self.scale // 2
        rect = pygame.Rect(self.x - half, self.y- half, half * 2, half * 2)
        return rect
    
    def draw_self(self,screen):
        if self.is_dead:
            return
        self_rect = self.get_rect()
        if player_image:
            scaled_image = pygame.transform.scale(player_image, (self.image_scale, self.image_scale))
            image_rect = scaled_image.get_rect()
            image_rect.midbottom = self_rect.midbottom
            screen.blit(scaled_image,image_rect)
        if SHOW_PLAYER_HITBOX:
            pygame.draw.rect(screen, (0, 0, 255), self_rect,2)
        

    def die(self):
        self.is_dead = True
        self.respawn_timer = 1  # 1 second respawn delay
    
    def respawn(self):
            self.x,self.y = self.respawn_pos
            self.velocity_y = 3 
            self.grounded = False
            self.collection_star_indexs = []
            self.is_dead = False
            self.respawn_timer = 0
            self.is_frozen_after_respawn = True

    def controll(self):
        def check_grounded_and_set_slope():
            ground = self.check_grounded()
            if ground is None:
                self.slope = None
                return
            x1 = ground[0][0]
            y1 = ground[0][1]
            x2 = ground[1][0]
            y2 = ground[1][1]
            dx = x2-x1
            dy = y2-y1
            if dx == 0:
                self.slope = None
                return
            self.slope = dy/dx
        
        def is_steep(horizontal_dir, standard):
            if self.slope is None:
                return False
            result = self.slope * horizontal_dir < 0 and abs(self.slope) >= standard
            return result

        def check_and_respawn():
            self.respawn_timer -= 1/60
            if self.respawn_timer <= 0:
                self.respawn()
        # keys = pygame.key.get_pressed()
        # if keys[pygame.K_LEFT]:
        #     dx -= 1
        # if keys[pygame.K_RIGHT]:
        #     dx += 1
        # if keys[pygame.K_UP] and self.grounded and not is_steep(dx,2):
        #     self.velocity_y = -self.jump_force
        #     self.move(0, self.velocity_y)
        # if keys[pygame.K_DOWN]:
        #     dx = 0
        #     while self.grounded:
        #         self.move(0, 2)
        #         self.check_grounded()
        if self.is_dead:
            check_and_respawn()
            return
        
        dx = 0
        if len(self.buttons) > 0 and self.buttons[0].pressed:
            dx -= 1
        if len(self.buttons) > 1 and self.buttons[1].pressed:
            dx += 1
        if len(self.buttons) > 2 and self.buttons[2].pressed and self.grounded and not is_steep(dx,2):
            self.velocity_y = -self.jump_force
            self.move(0, self.velocity_y)
        if len(self.buttons) > 3 and self.buttons[3].pressed:
            dx = 0
            while self.grounded:
                self.move(0, 2)
                self.check_grounded()

        if self.x < 0 and dx < 0:
            dx = 0
        elif self.x > graph_generator.SCREEN_WIDTH and dx > 0:
            dx = 0
        self.move(dx, 0)
        
        if dx != 0:
            self.is_frozen_after_respawn = False

        if self.is_frozen_after_respawn:
            return
        
        check_grounded_and_set_slope()

        falling = self.velocity_y > 0
        horizontal = self.velocity_y == 0 and dx != 0
        if self.grounded:
            if falling or horizontal:
                self.land()
            self.velocity_y = 0
        else:
            if horizontal:
                self.land(is_down=True)
            else:
                self.velocity_y += self.gravity
                self.velocity_y = min(self.velocity_y, self.max_velocity_y)
        self.move(0, self.velocity_y)
        if abs(self.y) > graph_generator.SCREEN_HEIGHT or self.check_collide_obstacles():
            self.die()
        
        self.handle_collecting_stars()
        

    def land(self, is_down = False):
        for i in range(graph_generator.SCREEN_HEIGHT):
            move_y = -1 if not is_down else 1
            self.move(0,move_y)
            self.check_grounded()
            if self.grounded == is_down:
                last_land = 1 if not is_down else 0
                self.move(0,last_land)
                self.grounded = True
                break
    def move(self,dx,dy):
        self.x += dx * self.speed
        self.y += dy

    def check_grounded(self):
        player_rect = self.get_rect()
        w_center = player_rect.left + (player_rect.width // 2)
        length = 4
        thickness = player_rect.height // 3
        sensor = pygame.Rect(
            w_center - (length // 2),
            player_rect.top + player_rect.height - thickness,
            length,
            thickness
        )
        result = graph_generator.check_collide_lines(sensor,self.platforms)
        self.grounded = not result is None
        return result
    
    def check_collide_obstacles(self):
        player_rect = self.get_rect()
        for obstacle in self.obstacles:
            if player_rect.colliderect(obstacle):
                return True
        return False
    
    def handle_collecting_stars(self):
        player_rect = self.get_rect()
        for i, star in enumerate(self.stars):
            if i in self.collection_star_indexs:
                continue
            if player_rect.colliderect(star):
                self.collection_star_indexs.append(i)
                print(f"Star collected! Index: {i}")
                if len(self.collection_star_indexs) >= len(self.stars):
                    print("Stage Clear!!, a number of stars collected:", len(self.collection_star_indexs))




def main():
    graph_generator.SCREEN_WIDTH = graph_generator.SCREEN_WIDTH
    graph_generator.SCREEN_HEIGHT = graph_generator.SCREEN_HEIGHT
    graph_generator.LINE_THICKNESS = 3

    expressions = []
    for i in range(2):
        expressions.append(input(f"function{i+1} y="))
    pygame.init()
    screen = pygame.display.set_mode((graph_generator.SCREEN_WIDTH, graph_generator.SCREEN_HEIGHT))
    pygame.display.set_caption("Player Controller")
    clock = pygame.time.Clock()
    running = True
    
    platforms = []
    for expr in expressions:
        platforms.extend(graph_generator.generate_lines(expr))
    player = Player(15,15,platforms)

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        player.controll()
        screen.fill((128,128,128))
        graph_generator.draw_lines(screen,platforms)
        player.draw_self(screen)
        pygame.display.flip()
        clock.tick(60)
    pygame.quit()
# if __name__ == "__main__":
#     main()